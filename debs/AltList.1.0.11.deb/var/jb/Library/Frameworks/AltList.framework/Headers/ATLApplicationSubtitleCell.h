#import <Preferences/PSTableCell.h>
#import <Preferences/PSSpecifier.h>

@interface ATLApplicationSubtitleCell : PSTableCell
{
	UILabel* _customValueLabel;
}
@end